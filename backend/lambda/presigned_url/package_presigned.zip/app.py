"""
OmniDrive AI - Phase 3: Presigned URL Generator & Ingestion Lambda Handler
File: lambda/presigned_url/handler.py
Route: POST /upload-url (Cognito JWT Authorizer Authenticated)

Responsibilities:
1. Extract Cognito 'sub' (User ID) from event['requestContext']['authorizer']['claims'].
2. Parse HTTP body: { "file_name": string, "file_type": string, "file_size": number }.
3. Generate a unique file_id (UUID v4).
4. Construct S3 Object Key: raw/{user_id}/{file_id}/{sanitized_file_name}.
5. Generate an S3 Presigned PUT URL valid for 300 seconds (5 minutes).
6. Persist initial item to DynamoDB table 'OmniDrive_Registry' with status 'PENDING_UPLOAD'.
7. Provide production CORS headers for all responses (including OPTIONS preflight).
"""

import json
import logging
import os
import re
import uuid
from datetime import datetime, timezone
import boto3
from botocore.exceptions import ClientError

# Logger setup
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS SDK clients
s3_client = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")

# Environment configuration
RAW_BUCKET_NAME = os.environ.get("RAW_BUCKET_NAME", "omnidrive-ai-raw-dev")
DYNAMODB_TABLE_NAME = os.environ.get("DYNAMODB_TABLE_NAME", "OmniDrive_Registry")
URL_EXPIRATION_SECONDS = int(os.environ.get("URL_EXPIRATION_SECONDS", "300"))  # 5 minutes

CORS_HEADERS = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type,Authorization,X-User-Id,X-Amz-Date,X-Api-Key,X-Amz-Security-Token",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
}


def lambda_handler(event, context):
    """
    AWS Lambda entrypoint for generating S3 presigned PUT URLs
    and registering initial upload records in DynamoDB.
    """
    logger.info("Received presigned URL generation request. Request ID: %s", getattr(context, "aws_request_id", "local"))

    # Handle CORS OPTIONS preflight request
    http_method = (
        event.get("httpMethod")
        or event.get("requestContext", {}).get("http", {}).get("method", "")
    ).upper()

    if http_method == "OPTIONS":
        return {
            "statusCode": 200,
            "headers": CORS_HEADERS,
            "body": json.dumps({"message": "CORS preflight successful"}),
        }

    try:
        # 1. Extract Cognito 'sub' (User ID) from authorizer claims
        user_id = extract_user_id(event)
        if not user_id:
            logger.warning("Unauthorized access attempt: missing Cognito 'sub' claim.")
            return build_response(401, {"error": "Unauthorized: Missing valid Cognito user identification claim."})

        # 2. Parse HTTP body: { "file_name": str, "file_type": str, "file_size": num }
        body = parse_request_body(event)
        file_name = body.get("file_name", "").strip()
        # Accept file_type (per prompt) or content_type
        file_type = (body.get("file_type") or body.get("content_type", "")).strip().lower()
        file_size = body.get("file_size", 0)

        if not file_name or not file_type:
            return build_response(400, {
                "error": "Missing required fields: 'file_name' and 'file_type' are required."
            })

        try:
            file_size = int(file_size)
        except (ValueError, TypeError):
            file_size = 0

        # Storage Quota Validation (15 GB Free Tier = 16,106,127,360 bytes)
        FREE_TIER_LIMIT_BYTES = int(os.environ.get("STORAGE_LIMIT_BYTES", str(15 * 1024 * 1024 * 1024)))
        table = dynamodb.Table(DYNAMODB_TABLE_NAME)
        user_pk = f"USER#{user_id}"

        try:
            from boto3.dynamodb.conditions import Key
            res = table.query(
                KeyConditionExpression=Key("PK").eq(user_pk) & Key("SK").begins_with("FILE#"),
                ProjectionExpression="file_size",
            )
            current_bytes = sum(int(i.get("file_size") or 0) for i in res.get("Items", []))
            if current_bytes + file_size > FREE_TIER_LIMIT_BYTES:
                return build_response(403, {
                    "error": "Storage quota exceeded: This upload would exceed your 15 GB Free Tier limit. Please delete unused files or upgrade to Pro Cloud."
                })
        except Exception as quota_err:
            logger.warning("Storage quota validation notice: %s", str(quota_err))

        # 3. Generate unique file_id (UUID v4) & sanitize filename
        file_id = str(uuid.uuid4())
        sanitized_file_name = sanitize_filename(file_name)

        # 4. Construct S3 Object Key: raw/{user_id}/{file_id}/{file_name}
        s3_raw_key = f"raw/{user_id}/{file_id}/{sanitized_file_name}"
        timestamp = datetime.now(timezone.utc).isoformat()

        # 5. Generate S3 Presigned PUT URL valid for 300 seconds (5 minutes)
        # Note: Do NOT add 'Metadata' to Params; metadata is persisted directly to DynamoDB,
        # and omitting it from Params prevents SigV4 signed-header mismatches on client PUT.
        presigned_put_url = s3_client.generate_presigned_url(
            ClientMethod="put_object",
            Params={
                "Bucket": RAW_BUCKET_NAME,
                "Key": s3_raw_key,
                "ContentType": file_type,
            },
            ExpiresIn=URL_EXPIRATION_SECONDS,
        )

        # 6. Save initial item to DynamoDB table OmniDrive_Registry
        table = dynamodb.Table(DYNAMODB_TABLE_NAME)
        registry_item = {
            "PK": f"USER#{user_id}",
            "SK": f"FILE#{file_id}",
            "file_id": file_id,
            "user_id": user_id,
            "file_name": sanitized_file_name,
            "file_type": file_type,
            "content_type": file_type,
            "file_size": file_size,
            "s3_raw_key": s3_raw_key,
            "s3_key": s3_raw_key,
            "s3_bucket": RAW_BUCKET_NAME,
            "status": "PENDING_UPLOAD",
            "pipeline_step": "AWAITING_UPLOAD",
            "created_at": timestamp,
            "updated_at": timestamp,
        }

        table.put_item(Item=registry_item)
        logger.info("Successfully registered PENDING_UPLOAD for file_id: %s (user: %s, key: %s)", file_id, user_id, s3_raw_key)

        # Return presigned URL with file details
        return build_response(200, {
            "upload_url": presigned_put_url,
            "file_id": file_id,
            "s3_key": s3_raw_key,
            "s3_raw_key": s3_raw_key,
            "file_name": sanitized_file_name,
            "file_type": file_type,
            "file_size": file_size,
            "status": "PENDING_UPLOAD",
            "expires_in": URL_EXPIRATION_SECONDS,
        })

    except ClientError as e:
        logger.error("AWS ClientError in presigned URL handler: %s", str(e), exc_info=True)
        return build_response(500, {"error": "AWS service error while preparing direct upload."})
    except Exception as e:
        logger.error("Unexpected error in presigned URL handler: %s", str(e), exc_info=True)
        return build_response(500, {"error": f"Internal server error: {str(e)}"})


def extract_user_id(event):
    """
    Extracts Cognito 'sub' (User ID) from:
    1. event['requestContext']['authorizer']['claims']['sub'] (REST API / Standard Authorizer)
    2. event['requestContext']['authorizer']['jwt']['claims']['sub'] (HTTP API v2 JWT Authorizer)
    3. Direct headers or body fallback (useful for local development)
    """
    authorizer = event.get("requestContext", {}).get("authorizer", {})

    # 1. Standard / REST API authorizer claims
    claims = authorizer.get("claims")
    if isinstance(claims, dict) and "sub" in claims:
        return claims["sub"]

    # 2. HTTP API v2 JWT authorizer claims
    jwt_claims = authorizer.get("jwt", {}).get("claims", {})
    if isinstance(jwt_claims, dict) and "sub" in jwt_claims:
        return jwt_claims["sub"]

    # 3. Development / Local test header fallback
    headers = event.get("headers") or {}
    for key in ("x-user-id", "X-User-Id", "X-USER-ID"):
        if key in headers and headers[key]:
            return headers[key]

    # 4. Fallback in body
    body = parse_request_body(event)
    return body.get("user_id")


def parse_request_body(event):
    """Parses JSON request body safely handling dict or string representations."""
    body = event.get("body")
    if not body:
        return {}
    if isinstance(body, dict):
        return body
    try:
        return json.loads(body)
    except (json.JSONDecodeError, TypeError):
        return {}


def sanitize_filename(filename):
    """Sanitizes filename for safe S3 key storage."""
    base = os.path.basename(filename)
    # Replace spaces and special characters with underscore, keeping extension and alphanumerics
    sanitized = re.sub(r"[^a-zA-Z0-9._-]", "_", base)
    return sanitized or "file_upload"


def build_response(status_code, body_dict):
    """Builds standardized API Gateway HTTP response with CORS headers."""
    return {
        "statusCode": status_code,
        "headers": CORS_HEADERS,
        "body": json.dumps(body_dict),
    }
