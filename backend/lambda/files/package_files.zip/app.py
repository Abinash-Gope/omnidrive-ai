"""
OmniDrive AI - Lambda Microservice: File Registry & Status API
Routes:
  - GET /files (Fetch authenticated user's file registry)
  - GET /files/{fileId} (Fetch detailed job status & AI metadata for a specific file)

Features:
- Cognito JWT Authorizer integration (enforces multi-tenant data isolation by user_id).
- DynamoDB Single-Table queries (PK: USER#<id>, SK: FILE#<id>).
- Filtering by processing status via 'UserStatusIndex' GSI (?status=COMPLETED).
- Full CORS headers for browser clients.
"""

import json
import logging
import os
from decimal import Decimal
import boto3
from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource("dynamodb")
s3_client = boto3.client("s3")
DYNAMODB_TABLE_NAME = os.environ.get("DYNAMODB_TABLE_NAME", "omnidrive-ai-registry-dev")
RAW_BUCKET_NAME = os.environ.get("RAW_BUCKET_NAME", "omnidrive-ai-raw-dev-01ed8837")


def enrich_file_urls(item):
    """Generates an authenticated S3 presigned GET URL for secure client viewing."""
    if not item:
        return item
    s3_key = item.get("s3_key") or item.get("s3_raw_key")
    bucket = item.get("s3_bucket") or RAW_BUCKET_NAME
    if s3_key and bucket:
        try:
            view_url = s3_client.generate_presigned_url(
                "get_object",
                Params={"Bucket": bucket, "Key": s3_key},
                ExpiresIn=3600,
            )
            item["download_url"] = view_url
            if not item.get("thumbnail_url"):
                item["thumbnail_url"] = view_url
        except Exception as e:
            logger.warning("Failed to generate presigned GET URL for key %s: %s", s3_key, str(e))
    return item


class DecimalEncoder(json.JSONEncoder):
    """Helper to serialize DynamoDB Decimal types to float/int"""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return int(obj) if obj % 1 == 0 else float(obj)
        return super(DecimalEncoder, self).default(obj)


def lambda_handler(event, context):
    logger.info("Handling File API request. Path: %s, Method: %s", event.get("rawPath") or event.get("path"), event.get("requestContext", {}).get("http", {}).get("method"))

    try:
        # 1. Authenticate user from Cognito JWT claims
        user_id = extract_user_id(event)
        if not user_id:
            return build_response(401, {"error": "Unauthorized: Missing valid Cognito authentication claim."})

        # 2. Extract path & route parameters
        http_method = (
            event.get("requestContext", {}).get("http", {}).get("method")
            or event.get("httpMethod", "GET")
        ).upper()

        path_parameters = event.get("pathParameters") or {}
        file_id = path_parameters.get("fileId")

        # Route 1: /files/{fileId}
        if file_id:
            if http_method == "DELETE":
                return handle_delete_file(user_id, file_id, event)
            return handle_get_file_detail(user_id, file_id)

        # Route 2: GET /files
        if http_method == "GET":
            query_params = event.get("queryStringParameters") or {}
            status_filter = query_params.get("status")
            return handle_list_user_files(user_id, status_filter)

        return build_response(405, {"error": f"Method {http_method} not allowed."})

    except ClientError as e:
        logger.error("AWS ClientError in files handler: %s", str(e), exc_info=True)
        return build_response(500, {"error": "AWS DynamoDB service error."})
    except Exception as e:
        logger.error("Unexpected error in files handler: %s", str(e), exc_info=True)
        return build_response(500, {"error": f"Internal server error: {str(e)}"})


def handle_list_user_files(user_id, status_filter=None):
    """
    Queries files belonging exclusively to the authenticated user.
    Uses 'UserStatusIndex' GSI when status_filter is supplied, or partition key query otherwise.
    """
    table = dynamodb.Table(DYNAMODB_TABLE_NAME)
    user_pk = f"USER#{user_id}"

    if status_filter:
        # Query GSI: UserStatusIndex (PK = user_pk AND status = status_filter)
        logger.info("Querying UserStatusIndex for user: %s with status: %s", user_id, status_filter)
        response = table.query(
            IndexName="UserStatusIndex",
            KeyConditionExpression=Key("PK").eq(user_pk) & Key("status").eq(status_filter),
        )
    else:
        # Query Table by partition key PK = USER#<id>
        logger.info("Querying all files for user: %s", user_id)
        response = table.query(
            KeyConditionExpression=Key("PK").eq(user_pk) & Key("SK").begins_with("FILE#"),
        )

    items = response.get("Items", [])

    # Sort descending by created_at (most recent first)
    items.sort(key=lambda x: x.get("created_at", ""), reverse=True)

    # Calculate exact byte-level storage metrics across user's files
    total_bytes = sum(int(item.get("file_size") or 0) for item in items)
    free_tier_limit_bytes = 15 * 1024 * 1024 * 1024  # 15 GB = 16,106,127,360 bytes
    used_percentage = min(100.0, round((total_bytes / free_tier_limit_bytes) * 100, 3)) if free_tier_limit_bytes > 0 else 0.0

    image_bytes = sum(int(item.get("file_size") or 0) for item in items if (item.get("content_type") or "").startswith("image/"))
    video_bytes = sum(int(item.get("file_size") or 0) for item in items if (item.get("content_type") or "").startswith("video/"))
    pdf_bytes = sum(int(item.get("file_size") or 0) for item in items if "pdf" in (item.get("content_type") or "").lower())
    other_bytes = max(0, total_bytes - (image_bytes + video_bytes + pdf_bytes))

    storage_info = {
        "used_bytes": total_bytes,
        "limit_bytes": free_tier_limit_bytes,
        "used_gb": round(total_bytes / (1024 ** 3), 4),
        "total_gb": 15.0,
        "used_percentage": used_percentage,
        "tier": "free",
        "breakdown": {
            "images_bytes": image_bytes,
            "videos_bytes": video_bytes,
            "documents_bytes": pdf_bytes,
            "other_bytes": other_bytes,
        },
    }

    # Enrich items with secure presigned GET URLs for direct high-res viewing in browser
    for item in items:
        enrich_file_urls(item)

    return build_response(
        200,
        {
            "user_id": user_id,
            "count": len(items),
            "files": items,
            "storage": storage_info,
        },
    )


def handle_get_file_detail(user_id, file_id):
    """
    Fetches a single file record by PK: USER#<id>, SK: FILE#<file_id>.
    Guarantees that a user cannot access another tenant's files.
    """
    table = dynamodb.Table(DYNAMODB_TABLE_NAME)
    user_pk = f"USER#{user_id}"
    clean_file_id = file_id.replace("FILE#", "").strip()
    file_sk = f"FILE#{clean_file_id}"

    logger.info("Fetching file detail: %s for user: %s", file_sk, user_pk)
    response = table.get_item(
        Key={
            "PK": user_pk,
            "SK": file_sk,
        }
    )

    item = response.get("Item")
    if not item:
        return build_response(404, {"error": f"File with ID '{clean_file_id}' not found."})

    enrich_file_urls(item)
    return build_response(200, {"file": item})


def handle_delete_file(user_id, file_id, event):
    """
    Deletes a file record from DynamoDB single-table (PK: USER#<id>, SK: FILE#<file_id>)
    and cleans up corresponding raw S3 object if present.
    """
    table = dynamodb.Table(DYNAMODB_TABLE_NAME)
    user_pk = f"USER#{user_id}"
    clean_file_id = file_id.replace("FILE#", "").strip()
    file_sk = f"FILE#{clean_file_id}"

    logger.info("Attempting to delete file: %s for user: %s", file_sk, user_pk)

    # 1. Fetch file record first to get S3 key
    get_res = table.get_item(Key={"PK": user_pk, "SK": file_sk})
    item = get_res.get("Item")

    # 2. Delete item from DynamoDB
    table.delete_item(Key={"PK": user_pk, "SK": file_sk})
    logger.info("Successfully deleted DynamoDB record: PK=%s, SK=%s", user_pk, file_sk)

    # 3. Clean up S3 object if s3_bucket and s3_key exist
    body = {}
    raw_body = event.get("body")
    if raw_body:
        try:
            body = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except Exception:
            body = {}

    s3_key = (item.get("s3_key") or item.get("s3_raw_key") if item else None) or body.get("s3_key")
    s3_bucket = (item.get("s3_bucket") if item else None) or body.get("s3_bucket") or os.environ.get("RAW_BUCKET_NAME", "omnidrive-ai-raw-dev-01ed8837")

    if s3_key and s3_bucket:
        try:
            s3_client = boto3.client("s3")
            s3_client.delete_object(Bucket=s3_bucket, Key=s3_key)
            logger.info("Deleted S3 object s3://%s/%s", s3_bucket, s3_key)
        except Exception as s3_err:
            logger.warning("Could not delete S3 object: %s", str(s3_err))

    return build_response(
        200,
        {
            "message": f"File '{clean_file_id}' successfully deleted from DynamoDB.",
            "file_id": clean_file_id,
        },
    )


def extract_user_id(event):
    """Extract user_id from Cognito JWT authorizer claims or headers"""
    jwt_claims = (
        event.get("requestContext", {})
        .get("authorizer", {})
        .get("jwt", {})
        .get("claims", {})
    )
    if "sub" in jwt_claims:
        return jwt_claims["sub"]

    cognito_claims = (
        event.get("requestContext", {})
        .get("authorizer", {})
        .get("claims", {})
    )
    if "sub" in cognito_claims:
        return cognito_claims["sub"]

    headers = event.get("headers") or {}
    for key in ("x-user-id", "X-User-Id", "X-USER-ID"):
        if key in headers:
            return headers[key]

    return None


def build_response(status_code, body):
    """Standard HTTP response with production CORS headers and Decimal support"""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization,X-User-Id,X-Amz-Date,X-Api-Key,X-Amz-Security-Token",
            "Access-Control-Allow-Methods": "OPTIONS,GET,POST,DELETE",
        },
        "body": json.dumps(body, cls=DecimalEncoder),
    }
